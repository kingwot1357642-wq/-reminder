package com.example.hanzireminder

import android.app.Application
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.hanzireminder.data.AppDatabase
import com.example.hanzireminder.data.Repository
import com.example.hanzireminder.data.Settings
import com.example.hanzireminder.data.Srs
import com.example.hanzireminder.data.SrsConfig
import com.example.hanzireminder.data.Word
import com.example.hanzireminder.reminder.ReminderScheduler
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class MainViewModel(app: Application) : AndroidViewModel(app) {
    private val ctx = app.applicationContext
    private val dao = AppDatabase.get(ctx).wordDao()

    /** ระดับ HSK ที่มีข้อมูลในแอป */
    val availableLevels: List<Int> = Repository.availableLevels(ctx)

    /** คำทั้งหมดในฐานข้อมูล */
    val words: StateFlow<List<Word>> = dao.observeAll()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    private val _levels = MutableStateFlow(Settings.levels(ctx))
    val levels: StateFlow<Set<Int>> = _levels

    /** คำที่อยู่ในระดับที่เลือกไว้ (รวมคำที่ผู้ใช้เพิ่มเอง) */
    val visibleWords: StateFlow<List<Word>> = combine(words, _levels) { all, lv ->
        all.filter { it.level == 0 || it.level in lv }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    private val _times = MutableStateFlow(Settings.times(ctx))
    val times: StateFlow<Set<String>> = _times

    private val _srs = MutableStateFlow(Settings.srs(ctx))
    val srs: StateFlow<SrsConfig> = _srs

    // คำที่กำลังทบทวนอยู่ในหน้าหลัก
    private val _current = MutableStateFlow<Word?>(null)
    val current: StateFlow<Word?> = _current

    private val _message = MutableStateFlow<String?>(null)
    val message: StateFlow<String?> = _message

    init {
        viewModelScope.launch(Dispatchers.IO) {
            Repository.ensureSeeded(ctx)
            loadNext()
        }
        _times.value.forEach { ReminderScheduler.schedule(ctx, it) }
    }

    private suspend fun loadNext() {
        _current.value = Repository.next(ctx, _current.value?.id ?: -1L)
    }

    fun skip() {
        viewModelScope.launch(Dispatchers.IO) { loadNext() }
    }

    fun rate(rating: Srs.Rating) {
        val word = _current.value ?: return
        viewModelScope.launch(Dispatchers.IO) {
            Repository.rate(ctx, word.id, rating)
            loadNext()
        }
    }

    // ---------- คำศัพท์ ----------

    fun addWord(hanzi: String, pinyin: String, meaning: String) {
        if (hanzi.isBlank()) return
        viewModelScope.launch(Dispatchers.IO) {
            dao.insert(Word(hanzi = hanzi.trim(), pinyin = pinyin.trim(), meaning = meaning.trim()))
        }
    }

    fun deleteWord(word: Word) {
        viewModelScope.launch(Dispatchers.IO) { dao.delete(word) }
    }

    // ---------- ตั้งค่า ----------

    fun addTime(time: String) {
        val updated = _times.value + time
        Settings.setTimes(ctx, updated)
        _times.value = updated
        ReminderScheduler.schedule(ctx, time)
    }

    fun removeTime(time: String) {
        val updated = _times.value - time
        Settings.setTimes(ctx, updated)
        _times.value = updated
        ReminderScheduler.cancel(ctx, time)
    }

    fun setLevels(newLevels: Set<Int>) {
        if (newLevels.isEmpty()) return
        Settings.setLevels(ctx, newLevels)
        _levels.value = newLevels
        viewModelScope.launch(Dispatchers.IO) { loadNext() }
    }

    fun setSrs(cfg: SrsConfig) {
        Settings.setSrs(ctx, cfg)
        _srs.value = cfg
    }

    // ---------- สำรอง / กู้คืน ----------

    fun exportTo(uri: Uri) {
        viewModelScope.launch(Dispatchers.IO) {
            try {
                val json = Repository.exportJson(ctx)
                ctx.contentResolver.openOutputStream(uri)?.use { it.write(json.toByteArray(Charsets.UTF_8)) }
                    ?: error("เปิดไฟล์ไม่ได้")
                _message.value = "สำรองข้อมูลเรียบร้อย"
            } catch (e: Exception) {
                _message.value = "สำรองไม่สำเร็จ: ${e.message}"
            }
        }
    }

    fun importFrom(uri: Uri) {
        viewModelScope.launch(Dispatchers.IO) {
            try {
                val text = ctx.contentResolver.openInputStream(uri)
                    ?.bufferedReader(Charsets.UTF_8)?.use { it.readText() }
                    ?: error("เปิดไฟล์ไม่ได้")
                val (applied, skipped) = Repository.importJson(ctx, text)

                val oldTimes = _times.value
                _levels.value = Settings.levels(ctx)
                _times.value = Settings.times(ctx)
                _srs.value = Settings.srs(ctx)
                (oldTimes - _times.value).forEach { ReminderScheduler.cancel(ctx, it) }
                _times.value.forEach { ReminderScheduler.schedule(ctx, it) }
                loadNext()
                _message.value = "กู้คืนแล้ว $applied คำ" + if (skipped > 0) " (ข้าม $skipped คำที่ไม่พบในแอป)" else ""
            } catch (e: Exception) {
                _message.value = "กู้คืนไม่สำเร็จ: ${e.message}"
            }
        }
    }

    fun clearMessage() {
        _message.value = null
    }
}
