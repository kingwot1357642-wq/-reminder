package com.example.hanzireminder.data

import android.content.Context
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import org.json.JSONArray
import org.json.JSONObject

object Repository {
    private val mutex = Mutex()
    private const val PREFS = "data"
    private val ALL_LEVELS = listOf(1, 2, 3, 4)

    private fun dao(context: Context) = AppDatabase.get(context).wordDao()

    /** ระดับ HSK ที่มีไฟล์คำศัพท์อยู่ในแอป (assets/hskN.json) */
    fun availableLevels(context: Context): List<Int> {
        val names = context.assets.list("")?.toSet() ?: emptySet()
        return ALL_LEVELS.filter { "hsk$it.json" in names }
    }

    private fun pickLevels(context: Context): List<Int> = Settings.levels(context).toList() + 0

    private suspend fun seedLocked(context: Context) {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        // รองรับเครื่องที่เคยลงเวอร์ชันก่อนหน้า (เคยโหลด HSK 1 แล้ว)
        if (prefs.getInt("seed_version", 0) >= 2 && !prefs.contains("seed_hsk1")) {
            prefs.edit().putBoolean("seed_hsk1", true).apply()
        }
        val d = dao(context)
        for (level in availableLevels(context)) {
            val key = "seed_hsk$level"
            if (prefs.getBoolean(key, false)) continue

            val json = context.assets.open("hsk$level.json")
                .bufferedReader(Charsets.UTF_8).use { it.readText() }
            val arr = JSONArray(json)
            val words = ArrayList<Word>(arr.length())
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                words.add(
                    Word(
                        hanzi = o.getString("h"),
                        pinyin = o.getString("p"),
                        meaning = o.getString("m"),
                        isBuiltIn = true,
                        example = o.getString("e"),
                        examplePinyin = o.getString("ep"),
                        exampleMeaning = o.getString("et"),
                        level = level,
                    ),
                )
            }
            d.deleteBuiltIn(level)
            d.insertAll(words)
            prefs.edit().putBoolean(key, true).apply()
        }
    }

    suspend fun ensureSeeded(context: Context) = mutex.withLock { seedLocked(context) }

    /** สุ่มคำถัดไปตามระบบทบทวนและระดับ HSK ที่เลือก (ไม่ซ้ำกับ excludeId) */
    suspend fun next(context: Context, excludeId: Long = -1L): Word? = mutex.withLock {
        seedLocked(context)
        Srs.pickNext(dao(context), pickLevels(context), excludeId)
    }

    suspend fun rate(context: Context, wordId: Long, rating: Srs.Rating) {
        mutex.withLock {
            val d = dao(context)
            val word = d.byId(wordId) ?: return@withLock
            d.update(Srs.rate(word, rating, Settings.srs(context)))
        }
    }

    // ---------- สำรอง / กู้คืนความคืบหน้า ----------

    suspend fun exportJson(context: Context): String = mutex.withLock {
        seedLocked(context)
        val root = JSONObject()
        root.put("app", "HanziReminder")
        root.put("format", 1)
        root.put("exportedAt", System.currentTimeMillis())

        val settings = JSONObject()
        settings.put("levels", JSONArray(Settings.levels(context).toList()))
        settings.put("times", JSONArray(Settings.times(context).toList()))
        val cfg = Settings.srs(context)
        settings.put("againMinutes", cfg.againMinutes)
        settings.put("knownDays", cfg.knownDays)
        settings.put("speed", cfg.speed)
        root.put("settings", settings)

        val words = JSONArray()
        for (w in dao(context).all()) {
            if (w.isBuiltIn && w.seenCount == 0) continue // คำที่ยังไม่เคยเรียนไม่ต้องเก็บ
            val o = JSONObject()
            o.put("h", w.hanzi)
            o.put("lv", w.level)
            o.put("b", w.box)
            o.put("s", w.seenCount)
            o.put("l", w.lastReviewed)
            o.put("d", w.nextDue)
            if (!w.isBuiltIn) {
                o.put("u", 1)
                o.put("p", w.pinyin)
                o.put("m", w.meaning)
                o.put("e", w.example)
                o.put("ep", w.examplePinyin)
                o.put("et", w.exampleMeaning)
            }
            words.put(o)
        }
        root.put("words", words)
        root.toString()
    }

    /** คืนค่า (จำนวนคำที่กู้คืน, จำนวนที่ข้าม) */
    suspend fun importJson(context: Context, text: String): Pair<Int, Int> = mutex.withLock {
        seedLocked(context)
        val root = JSONObject(text)
        require(root.optString("app") == "HanziReminder") { "ไม่ใช่ไฟล์สำรองของแอปนี้" }
        val d = dao(context)

        root.optJSONObject("settings")?.let { s ->
            val levels = s.optJSONArray("levels")
            if (levels != null && levels.length() > 0) {
                Settings.setLevels(context, (0 until levels.length()).map { levels.getInt(it) }.toSet())
            }
            val times = s.optJSONArray("times")
            if (times != null) {
                Settings.setTimes(context, (0 until times.length()).map { times.getString(it) }.toSet())
            }
            Settings.setSrs(
                context,
                SrsConfig(
                    againMinutes = s.optInt("againMinutes", 10),
                    knownDays = s.optInt("knownDays", 90),
                    speed = s.optInt("speed", 1),
                ),
            )
        }

        var applied = 0
        var skipped = 0
        val arr = root.optJSONArray("words") ?: JSONArray()
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            val hanzi = o.getString("h")
            val level = o.optInt("lv", 0)
            val isUser = o.optInt("u", 0) == 1
            val existing = if (isUser) d.findUser(hanzi) else d.findBuiltIn(level, hanzi)
            if (existing == null && !isUser) {
                skipped++
                continue
            }
            val base = existing ?: Word(
                hanzi = hanzi,
                pinyin = o.optString("p"),
                meaning = o.optString("m"),
                example = o.optString("e"),
                examplePinyin = o.optString("ep"),
                exampleMeaning = o.optString("et"),
                level = 0,
            )
            val merged = base.copy(
                box = o.optInt("b", 0),
                seenCount = o.optInt("s", 0),
                lastReviewed = o.optLong("l", 0L),
                nextDue = o.optLong("d", 0L),
            )
            if (existing == null) d.insert(merged) else d.update(merged)
            applied++
        }
        Pair(applied, skipped)
    }
}
