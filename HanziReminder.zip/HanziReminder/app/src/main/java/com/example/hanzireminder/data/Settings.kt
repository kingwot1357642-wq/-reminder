package com.example.hanzireminder.data

import android.content.Context

object Settings {
    private const val PREFS = "settings"
    private val defaultTimes = setOf("08:00", "20:00")

    private fun prefs(context: Context) =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    fun times(context: Context): Set<String> =
        prefs(context).getStringSet("reminder_times", defaultTimes) ?: defaultTimes

    fun setTimes(context: Context, times: Set<String>) {
        prefs(context).edit().putStringSet("reminder_times", times).apply()
    }

    /** ระดับ HSK ที่เลือกเรียน (ค่าเริ่มต้น HSK 1) */
    fun levels(context: Context): Set<Int> {
        val raw = prefs(context).getStringSet("levels", setOf("1")) ?: setOf("1")
        val parsed = raw.mapNotNull { it.toIntOrNull() }.toSet()
        return if (parsed.isEmpty()) setOf(1) else parsed
    }

    fun setLevels(context: Context, levels: Set<Int>) {
        prefs(context).edit().putStringSet("levels", levels.map { it.toString() }.toSet()).apply()
    }

    fun srs(context: Context): SrsConfig {
        val p = prefs(context)
        return SrsConfig(
            againMinutes = p.getInt("again_minutes", 10),
            knownDays = p.getInt("known_days", 90),
            speed = p.getInt("speed", 1),
        )
    }

    fun setSrs(context: Context, cfg: SrsConfig) {
        prefs(context).edit()
            .putInt("again_minutes", cfg.againMinutes)
            .putInt("known_days", cfg.knownDays)
            .putInt("speed", cfg.speed)
            .apply()
    }
}
