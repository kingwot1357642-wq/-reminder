package com.example.hanzireminder.data

import kotlin.random.Random

/** ตั้งค่าช่วงเวลาทบทวน (ผู้ใช้ปรับได้ในแท็บเพิ่มเติม) */
data class SrsConfig(
    val againMinutes: Int = 10, // กด "ไม่รู้" แล้วเจออีกใน (นาที)
    val knownDays: Int = 90, // กด "รู้แล้ว" แล้วเจออีกใน (วัน)
    val speed: Int = 1, // 0 = ถี่, 1 = ปกติ, 2 = ห่างๆ (คูณช่วง 8 ชม. ถึง 30 วัน)
)

/**
 * ระบบทบทวนแบบเว้นช่วงเวลา (กล่อง 0-7)
 *  - ไม่รู้   -> กลับกล่อง 0 เจออีกตามที่ตั้ง (ค่าเริ่มต้น 10 นาที)
 *  - รู้      -> ขึ้นกล่องถัดไป ช่วงห่างยาวขึ้น (8 ชม., 1, 3, 7, 14, 30 วัน)
 *  - รู้แล้ว  -> กล่อง 7 นานๆ ครั้งจึงกลับมา (ค่าเริ่มต้น 90 วัน)
 *  - คำใหม่ (ยังไม่เคยเห็น) จะถูกสุ่มมาเรื่อยๆ จนกว่าจะกดรู้หรือรู้แล้ว
 */
object Srs {
    const val KNOWN_BOX = 7

    enum class Rating { AGAIN, GOOD, KNOWN }

    private const val MIN = 60_000L
    private const val HOUR = 60 * MIN
    private const val DAY = 24 * HOUR

    // ช่วงห่างของกล่อง 1..6
    private val ladder = longArrayOf(8 * HOUR, 1 * DAY, 3 * DAY, 7 * DAY, 14 * DAY, 30 * DAY)

    fun intervalMs(box: Int, cfg: SrsConfig): Long = when {
        box <= 0 -> cfg.againMinutes * MIN
        box >= KNOWN_BOX -> cfg.knownDays * DAY
        else -> {
            val mult = when (cfg.speed) {
                0 -> 0.5
                2 -> 2.0
                else -> 1.0
            }
            (ladder[box - 1] * mult).toLong()
        }
    }

    fun rate(
        word: Word,
        rating: Rating,
        cfg: SrsConfig,
        now: Long = System.currentTimeMillis(),
    ): Word {
        val newBox = when (rating) {
            Rating.AGAIN -> 0
            Rating.GOOD ->
                if (word.box >= KNOWN_BOX) KNOWN_BOX else minOf(word.box + 1, KNOWN_BOX - 1)
            Rating.KNOWN -> KNOWN_BOX
        }
        return word.copy(
            box = newBox,
            seenCount = word.seenCount + 1,
            lastReviewed = now,
            nextDue = now + intervalMs(newBox, cfg),
        )
    }

    /** ความคืบหน้ารวม 0.0 - 1.0 (คำที่รู้แล้ว = เต็ม, คำที่ยังไม่เคยเห็น = 0) */
    fun progress(words: List<Word>): Float {
        if (words.isEmpty()) return 0f
        var sum = 0.0
        for (w in words) {
            if (w.seenCount > 0) sum += w.box.coerceIn(0, KNOWN_BOX) / KNOWN_BOX.toDouble()
        }
        return (sum / words.size).toFloat()
    }

    private fun weightOf(word: Word): Double = when (word.box) {
        0 -> 6.0
        1 -> 4.0
        2 -> 3.0
        3 -> 2.0
        4 -> 1.5
        5 -> 1.0
        else -> 0.8
    }

    /** เลือกคำถัดไปแบบสุ่มถ่วงน้ำหนัก: คำที่จำไม่ได้มาบ่อยสุด คำที่รู้แล้วมาน้อยลง */
    suspend fun pickNext(
        dao: WordDao,
        levels: List<Int>,
        excludeId: Long = -1L,
        now: Long = System.currentTimeMillis(),
    ): Word? {
        val learning = dao.dueLearning(levels, now, excludeId, 30)
        val fresh = dao.newWords(levels, excludeId, 5)
        val known = dao.dueKnown(levels, now, excludeId, 5)

        val candidates = ArrayList<Pair<Word, Double>>()
        learning.forEach { candidates.add(it to weightOf(it)) }
        // ถ้ามีคำค้างทบทวนเยอะ ลดโอกาสเจอคำใหม่ลง จะได้ไม่ท่วม
        val freshWeight = if (learning.size >= 15) 0.5 else 3.0
        fresh.forEach { candidates.add(it to freshWeight) }
        known.forEach { candidates.add(it to 0.5) }

        if (candidates.isEmpty()) {
            return dao.earliest(levels, excludeId) ?: dao.earliest(levels, -1L)
        }
        val total = candidates.sumOf { it.second }
        var r = Random.nextDouble() * total
        for ((word, weight) in candidates) {
            r -= weight
            if (r <= 0) return word
        }
        return candidates.last().first
    }
}
