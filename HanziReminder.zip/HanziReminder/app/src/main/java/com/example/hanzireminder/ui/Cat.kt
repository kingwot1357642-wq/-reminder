package com.example.hanzireminder.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/** หน้าแมววาดด้วยโค้ด (กริด 108 หน่วย เหมือนไอคอนแอป) */
@Composable
fun CatFace(
    modifier: Modifier = Modifier,
    body: Color = Violet,
    innerEar: Color = Rose,
) {
    Canvas(modifier) {
        val w = size.width
        val h = size.height
        fun x(v: Float) = v / 108f * w
        fun y(v: Float) = v / 108f * h

        // หู
        val leftEar = Path().apply {
            moveTo(x(31f), y(46f)); lineTo(x(33f), y(26f)); lineTo(x(48f), y(38f)); close()
        }
        val rightEar = Path().apply {
            moveTo(x(77f), y(46f)); lineTo(x(75f), y(26f)); lineTo(x(60f), y(38f)); close()
        }
        drawPath(leftEar, body)
        drawPath(rightEar, body)
        val leftInner = Path().apply {
            moveTo(x(35f), y(41f)); lineTo(x(35.5f), y(32f)); lineTo(x(43f), y(38f)); close()
        }
        val rightInner = Path().apply {
            moveTo(x(73f), y(41f)); lineTo(x(72.5f), y(32f)); lineTo(x(65f), y(38f)); close()
        }
        drawPath(leftInner, innerEar)
        drawPath(rightInner, innerEar)

        // หัว
        drawOval(body, topLeft = Offset(x(30f), y(37f)), size = Size(x(48f), y(42f)))

        // ตา
        drawOval(Gold, topLeft = Offset(x(40.5f), y(50.5f)), size = Size(x(9f), y(11f)))
        drawOval(Gold, topLeft = Offset(x(58.5f), y(50.5f)), size = Size(x(9f), y(11f)))
        drawOval(InkDark, topLeft = Offset(x(43.5f), y(51.5f)), size = Size(x(3f), y(9f)))
        drawOval(InkDark, topLeft = Offset(x(61.5f), y(51.5f)), size = Size(x(3f), y(9f)))

        // จมูก
        val nose = Path().apply {
            moveTo(x(51.5f), y(64f)); lineTo(x(56.5f), y(64f)); lineTo(x(54f), y(67.5f)); close()
        }
        drawPath(nose, Rose)

        // ปาก
        val stroke = x(1.2f)
        drawLine(InkDark, Offset(x(54f), y(67.5f)), Offset(x(54f), y(70f)), strokeWidth = stroke, cap = StrokeCap.Round)
        drawLine(InkDark, Offset(x(54f), y(70f)), Offset(x(50.5f), y(72f)), strokeWidth = stroke, cap = StrokeCap.Round)
        drawLine(InkDark, Offset(x(54f), y(70f)), Offset(x(57.5f), y(72f)), strokeWidth = stroke, cap = StrokeCap.Round)

        // หนวด
        val whisker = Color.White.copy(alpha = 0.85f)
        drawLine(whisker, Offset(x(30f), y(63f)), Offset(x(40f), y(64.5f)), strokeWidth = stroke, cap = StrokeCap.Round)
        drawLine(whisker, Offset(x(30f), y(68f)), Offset(x(40f), y(67f)), strokeWidth = stroke, cap = StrokeCap.Round)
        drawLine(whisker, Offset(x(78f), y(63f)), Offset(x(68f), y(64.5f)), strokeWidth = stroke, cap = StrokeCap.Round)
        drawLine(whisker, Offset(x(78f), y(68f)), Offset(x(68f), y(67f)), strokeWidth = stroke, cap = StrokeCap.Round)
    }
}

/** ภาพปกหน้าหลัก */
@Composable
fun CatCover(modifier: Modifier = Modifier) {
    Card(
        modifier = modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = Violet),
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 18.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(14.dp),
        ) {
            CatFace(
                modifier = Modifier.size(84.dp),
                body = Color(0xFFE6D6FF),
                innerEar = Rose,
            )
            Column {
                Text("学中文", fontSize = 30.sp, fontWeight = FontWeight.Bold, color = Color.White)
                Text("เรียนจีนกับแมวม่วง 🐾", fontSize = 14.sp, color = Color(0xFFEADFFF))
            }
        }
    }
}
