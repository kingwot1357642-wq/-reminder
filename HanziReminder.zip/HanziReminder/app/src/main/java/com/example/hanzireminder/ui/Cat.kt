package com.example.hanzireminder.ui

import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import com.example.hanzireminder.R

/** ภาพปกหน้าหลัก (แมวม่วง 学中文 เรียนจีนกับแมวม่วง) */
@Composable
fun CatCover(modifier: Modifier = Modifier) {
    Image(
        painter = painterResource(R.drawable.cover_header),
        contentDescription = "学中文 เรียนจีนกับแมวม่วง",
        contentScale = ContentScale.FillWidth,
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(28.dp)),
    )
}
