package com.example.hanzireminder.ui

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.hanzireminder.R

/** cx = กึ่งกลางแท็บ, w/h = ขนาดไอคอน (หน่วยอ้างอิงกว้าง 842) ทุกค่าวัดบนแถบกว้าง 800 */
private class NavDef(val label: String, val icon: Int, val cx: Float, val w: Float, val h: Float)

private val navDefs = listOf(
    NavDef("หน้าหลัก", R.drawable.ui_nav_house, 117f, 86f, 74f),
    NavDef("คำศัพท์", R.drawable.ui_nav_book, 308f, 89f, 72f),
    NavDef("สนุก", R.drawable.ui_nav_cat, 490f, 86f, 75f),
    NavDef("เพิ่มเติม", R.drawable.ui_nav_gear, 681f, 83f, 80f),
)

/** แถบล่าง: ภาพแถบเปล่า + แผ่นไฮไลต์ + ไอคอนแยกชิ้น + ชื่อแท็บตัวอักษรจริง */
@Composable
fun CatNavBar(selected: Int, onSelect: (Int) -> Unit) {
    BoxWithConstraints(Modifier.fillMaxWidth().navigationBarsPadding()) {
        val u = maxWidth.value / 842f
        fun d(v: Float) = (v * u).dp
        Box(Modifier.fillMaxWidth().height(d(166f))) {
            // แถบกว้าง 800 กลางจอ
            Box(Modifier.offset(d(21f), d(10f)).size(d(800f), d(146f))) {
                Image(
                    painterResource(R.drawable.ui_nav), null,
                    Modifier.size(d(800f), d(146f)), contentScale = ContentScale.FillBounds,
                )
                val sel = navDefs[selected]
                Box(
                    Modifier
                        .offset(d(sel.cx - 93f), d(14f))
                        .size(d(187f), d(119f))
                        .background(Color(0xFFD7BEFB), RoundedCornerShape(d(52f))),
                )
                navDefs.forEachIndexed { i, n ->
                    Image(
                        painterResource(n.icon), null,
                        Modifier.offset(d(n.cx - n.w / 2f), d(55f - n.h / 2f)).size(d(n.w), d(n.h)),
                        contentScale = ContentScale.FillBounds,
                    )
                    Box(
                        Modifier.offset(d(n.cx - 85f), d(88f)).size(d(170f), d(46f)),
                        contentAlignment = Alignment.Center,
                    ) {
                        Text(
                            n.label,
                            fontSize = (u * 25f).sp,
                            fontWeight = if (i == selected) FontWeight.ExtraBold else FontWeight.Bold,
                            color = Color(0xFF4A1E9E),
                            maxLines = 1,
                        )
                    }
                    val src = remember { MutableInteractionSource() }
                    Box(
                        Modifier
                            .offset(d(n.cx - 95f), d(0f))
                            .size(d(190f), d(146f))
                            .clickable(interactionSource = src, indication = null) { onSelect(i) },
                    )
                }
            }
        }
    }
}
