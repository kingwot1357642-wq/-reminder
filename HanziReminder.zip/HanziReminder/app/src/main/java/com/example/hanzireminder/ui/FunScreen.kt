@file:OptIn(ExperimentalMaterial3Api::class)

package com.example.hanzireminder.ui

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.hanzireminder.MainViewModel
import com.example.hanzireminder.data.status

@Composable
fun FunScreen(vm: MainViewModel) {
    val words by vm.visibleWords.collectAsStateWithLifecycle()
    var zone by remember { mutableStateOf<String?>(null) }
    var expandedId by remember { mutableStateOf(-1L) }

    BackHandler(enabled = zone != null) { zone = null }

    if (zone == "single") {
        val single = remember(words) { words.filter { it.hanzi.length == 1 } }
        LazyColumn(
            modifier = Modifier.fillMaxWidth(),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            item {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    TextButton(onClick = { zone = null }) { Text("← กลับ") }
                    Text(
                        "คำพยางค์เดียว (${single.size})",
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold,
                    )
                }
            }
            item {
                Text(
                    "ตัวอักษรเดี่ยวที่เป็นรากของคำอื่นอีกมาก แตะเพื่อดูประโยคตัวอย่าง",
                    style = MaterialTheme.typography.bodySmall,
                    color = InkSoft,
                )
            }
            items(single, key = { it.id }) { w ->
                Card(
                    modifier = Modifier.fillMaxWidth().clickable { expandedId = if (expandedId == w.id) -1L else w.id },
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                ) {
                    Column(Modifier.padding(horizontal = 14.dp, vertical = 10.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(w.hanzi, fontSize = 32.sp, fontWeight = FontWeight.Bold, color = Coral)
                            Column(Modifier.weight(1f).padding(start = 14.dp)) {
                                Text(w.pinyin, fontSize = 16.sp, color = Sky, fontWeight = FontWeight.Medium)
                                Text(w.meaning, fontSize = 14.sp)
                            }
                            Text(
                                statusLabel(w.status()),
                                fontSize = 11.sp,
                                color = statusColor(w.status()),
                                fontWeight = FontWeight.Bold,
                            )
                        }
                        if (expandedId == w.id && w.example.isNotEmpty()) {
                            Column(Modifier.padding(top = 8.dp), verticalArrangement = Arrangement.spacedBy(1.dp)) {
                                Text(w.example, fontSize = 15.sp)
                                Text(w.examplePinyin, fontSize = 12.sp, color = InkSoft)
                                Text(w.exampleMeaning, fontSize = 13.sp, color = InkSoft)
                            }
                        }
                    }
                }
            }
        }
        return
    }

    val singleCount = words.count { it.hanzi.length == 1 }
    LazyColumn(
        modifier = Modifier.fillMaxWidth(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        item {
            Text("สนุก", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        }
        item {
            ZoneCard(
                icon = "🔤",
                title = "คำพยางค์เดียว",
                subtitle = "$singleCount ตัวอักษร พร้อมพินอินและความหมาย",
                color = MaterialTheme.colorScheme.primaryContainer,
                enabled = true,
            ) { zone = "single" }
        }
        item {
            ZoneCard(
                icon = "📜",
                title = "สุภาษิต",
                subtitle = "เร็วๆ นี้ (อัปเดตรอบถัดไป)",
                color = MaterialTheme.colorScheme.tertiaryContainer,
                enabled = false,
            ) {}
        }
        item {
            ZoneCard(
                icon = "🏠",
                title = "ศัพท์ในชีวิตประจำวัน",
                subtitle = "เร็วๆ นี้ (อัปเดตรอบถัดไป)",
                color = MaterialTheme.colorScheme.secondaryContainer,
                enabled = false,
            ) {}
        }
    }
}

@Composable
private fun ZoneCard(
    icon: String,
    title: String,
    subtitle: String,
    color: Color,
    enabled: Boolean,
    onClick: () -> Unit,
) {
    Card(
        modifier = Modifier.fillMaxWidth().clickable(enabled = enabled) { onClick() },
        colors = CardDefaults.cardColors(containerColor = color),
    ) {
        Row(Modifier.padding(20.dp), verticalAlignment = Alignment.CenterVertically) {
            Text(icon, fontSize = 36.sp)
            Column(Modifier.padding(start = 16.dp)) {
                Text(title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                Text(subtitle, style = MaterialTheme.typography.bodyMedium, color = InkSoft)
            }
        }
    }
}
