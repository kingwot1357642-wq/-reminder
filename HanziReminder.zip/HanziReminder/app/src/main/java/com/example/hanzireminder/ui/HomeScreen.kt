@file:OptIn(ExperimentalMaterial3Api::class)

package com.example.hanzireminder.ui

import android.speech.tts.TextToSpeech
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.mutableStateOf
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import java.util.Locale
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.hanzireminder.MainViewModel
import com.example.hanzireminder.data.Srs
import com.example.hanzireminder.data.Status
import com.example.hanzireminder.data.status

@Composable
fun HomeScreen(vm: MainViewModel) {
    val words by vm.visibleWords.collectAsStateWithLifecycle()
    val current by vm.current.collectAsStateWithLifecycle()

    val ctx = LocalContext.current
    val ttsRef = remember { mutableStateOf<TextToSpeech?>(null) }
    DisposableEffect(Unit) {
        val t = TextToSpeech(ctx) { st ->
            if (st == TextToSpeech.SUCCESS) ttsRef.value?.setLanguage(Locale.CHINA)
        }
        ttsRef.value = t
        onDispose { t.shutdown() }
    }

    val progress = remember(words) { Srs.progress(words) }
    val percent = (progress * 100).toInt()
    val newCount = words.count { it.status() == Status.NEW }
    val learningCount = words.count { it.status() == Status.LEARNING }
    val knownCount = words.count { it.status() == Status.KNOWN }

    LazyColumn(
        modifier = Modifier.fillMaxWidth(),
        contentPadding = androidx.compose.foundation.layout.PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        item { CatCover() }

        // ---------- ความคืบหน้า ----------
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 3.dp),
            ) {
                Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            "🐾 ความคืบหน้า",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.weight(1f),
                        )
                        Text("$percent%", fontSize = 28.sp, fontWeight = FontWeight.Bold, color = Violet)
                    }
                    ProgressBar(progress)
                    Text(
                        "📖 รู้แล้ว $knownCount   ⭐ กำลังเรียน $learningCount   🏆 ใหม่ $newCount",
                        style = MaterialTheme.typography.bodyMedium,
                        color = InkDark,
                    )
                }
            }
        }

        // ---------- คำศัพท์แนะนำ ----------
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 3.dp),
            ) {
                val w = current
                Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text(
                        "คำศัพท์แนะนำ",
                        style = MaterialTheme.typography.labelLarge,
                        color = Violet,
                        fontWeight = FontWeight.Bold,
                    )
                    if (w == null) {
                        Text("กำลังโหลดคำศัพท์...", color = InkSoft)
                    } else {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Row(
                                modifier = Modifier.weight(1f),
                                verticalAlignment = Alignment.Bottom,
                                horizontalArrangement = Arrangement.spacedBy(10.dp),
                            ) {
                                Text(w.hanzi, fontSize = 40.sp, fontWeight = FontWeight.Bold, color = Color(0xFF3B2478))
                                Text(w.pinyin, fontSize = 20.sp, color = Lilac, modifier = Modifier.padding(bottom = 6.dp))
                            }
                            Box(
                                modifier = Modifier
                                    .size(46.dp)
                                    .clip(CircleShape)
                                    .background(MaterialTheme.colorScheme.primaryContainer)
                                    .clickable { ttsRef.value?.speak(w.hanzi, TextToSpeech.QUEUE_FLUSH, null, "word") },
                                contentAlignment = Alignment.Center,
                            ) { Text("🔊", fontSize = 20.sp) }
                        }
                        Text(
                            "แปลว่า ${w.meaning}",
                            style = MaterialTheme.typography.titleMedium,
                        )
                        if (w.example.isNotEmpty()) {
                            Column(
                                modifier = Modifier.padding(top = 6.dp),
                                verticalArrangement = Arrangement.spacedBy(1.dp),
                            ) {
                                Text(w.example, fontSize = 15.sp)
                                Text(w.examplePinyin, fontSize = 12.sp, color = InkSoft)
                                Text(w.exampleMeaning, fontSize = 13.sp, color = InkSoft)
                            }
                        }
                    }
                }
            }
        }

        // ---------- ปุ่ม ----------
        item {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
                    BigButton("✕ ไม่รู้", Color(0xFFE5575A), Modifier.weight(1f)) { vm.rate(Srs.Rating.AGAIN) }
                    BigButton("✓ รู้", Color(0xFF3FBF6F), Modifier.weight(1f)) { vm.rate(Srs.Rating.GOOD) }
                    BigButton("★ รู้แล้ว", Violet, Modifier.weight(1f)) { vm.rate(Srs.Rating.KNOWN) }
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        "ไม่รู้ = ทวนเร็วๆ  ·  รู้ = ทวนห่างขึ้น  ·  รู้แล้ว = นานๆ ทวนที",
                        style = MaterialTheme.typography.bodySmall,
                        color = InkSoft,
                        modifier = Modifier.weight(1f),
                    )
                    TextButton(onClick = { vm.skip() }) { Text("ข้าม") }
                }
            }
        }
    }
}
