package com.example.hanzireminder.ui

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.foundation.background
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.hanzireminder.MainViewModel
import com.example.hanzireminder.R
import com.example.hanzireminder.data.Srs
import com.example.hanzireminder.data.Status
import com.example.hanzireminder.data.status
import kotlin.random.Random
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.launch

private val Ink = Color(0xFF4A1E9E)
private val PinyinPurple = Color(0xFF9B6BE8)
private val Gray = Color(0xFF7A6A94)

/**
 * หน้าหลักประกอบจากหลายชั้นภาพ (พิกัดอ้างอิงกว้าง 842 หน่วย):
 * พื้นหลังเต็มจอ (อยู่ที่ MainActivity) → ปก → กรอบก้อนเมฆความคืบหน้า / คำศัพท์ / ปุ่ม 3 ปุ่ม
 * กรอบและปุ่มลอยขยับแบบสุ่มช้าๆ ภายในช่วงที่ไม่หลุดจอ
 */
@Composable
fun HomeScreen(vm: MainViewModel) {
    val words by vm.visibleWords.collectAsStateWithLifecycle()
    val current by vm.current.collectAsStateWithLifecycle()

    val progress = remember(words) { Srs.progress(words) }
    val percent = (progress * 100).toInt()
    val newCount = words.count { it.status() == Status.NEW }
    val learningCount = words.count { it.status() == Status.LEARNING }
    val knownCount = words.count { it.status() == Status.KNOWN }

    BoxWithConstraints(Modifier.fillMaxSize()) {
        val u = maxWidth.value / 842f
        fun d(v: Float): Dp = (v * u).dp
        fun f(v: Float) = (v * u).sp

        Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
            Box(Modifier.fillMaxWidth().height(d(1430f))) {
                // ---------- ปก ----------
                Image(
                    painterResource(R.drawable.ui_header), null,
                    Modifier.fillMaxWidth().height(d(357f)),
                    contentScale = ContentScale.FillBounds,
                )

                // ---------- ความคืบหน้า (กรอบก้อนเมฆ 800x265) ----------
                Floaty(Modifier.offset(d(21f), d(380f)).size(d(800f), d(265f)), 18f, 12f, u, 1) {
                    Image(
                        painterResource(R.drawable.ui_progress), null,
                        Modifier.size(d(800f), d(265f)), contentScale = ContentScale.FillBounds,
                    )
                    val p = progress.coerceIn(0.04f, 0.96f)
                    val trackW = 654f
                    Box(
                        Modifier
                            .offset(d(86f), d(140f))
                            .size(d(trackW * p), d(38f))
                            .clip(RoundedCornerShape(d(19f)))
                            .background(Brush.horizontalGradient(listOf(Color(0xFF8D62E4), Color(0xFFDC96EE)))),
                    )
                    Image(
                        painterResource(R.drawable.ui_thumb), null,
                        Modifier.offset(d(86f + trackW * p - 34f), d(159f - 34f)).size(d(68f)),
                        contentScale = ContentScale.FillBounds,
                    )
                    Box(Modifier.offset(d(300f), d(62f)).size(d(256f), d(70f)), contentAlignment = Alignment.CenterEnd) {
                        Text("$percent%", fontSize = f(56f), fontWeight = FontWeight.ExtraBold, color = Ink, maxLines = 1)
                    }
                    listOf(156f to "รู้แล้ว $knownCount", 400f to "กำลังเรียน $learningCount", 650f to "ใหม่ $newCount").forEach { (cx, t) ->
                        Box(Modifier.offset(d(cx - 110f), d(199f)).size(d(220f), d(44f)), contentAlignment = Alignment.Center) {
                            Text(t, fontSize = f(25f), fontWeight = FontWeight.Bold, color = Ink, maxLines = 1)
                        }
                    }
                }

                // ---------- คำศัพท์แนะนำ (กรอบก้อนเมฆ 700x465 เล็กลง ~10%) ----------
                Floaty(Modifier.offset(d(54f), d(672f)).size(d(735f), d(488f)), 28f, 14f, u, 2) {
                    Image(
                        painterResource(R.drawable.ui_word), null,
                        Modifier.size(d(735f), d(488f)), contentScale = ContentScale.FillBounds,
                    )
                    val w = current
                    Box(Modifier.offset(d(88f), d(150f)).width(d(465f))) {
                        if (w == null) {
                            Text("กำลังโหลดคำศัพท์...", fontSize = f(30f), color = Gray)
                        } else {
                            Column {
                                val hs = when (w.hanzi.length) { 1, 2 -> 80f; 3 -> 62f; else -> 46f }
                                Row(verticalAlignment = Alignment.Bottom) {
                                    Text(w.hanzi, fontSize = f(hs), fontWeight = FontWeight.Bold, color = Ink, maxLines = 1)
                                    Spacer(Modifier.width(d(14f)))
                                    Text(
                                        w.pinyin, fontSize = f(34f), color = PinyinPurple, fontWeight = FontWeight.Medium,
                                        modifier = Modifier.weight(1f, fill = false).offset(y = d(-6f)),
                                    )
                                }
                                Spacer(Modifier.height(d(2f)))
                                Text("แปลว่า ${w.meaning}", fontSize = f(32f), lineHeight = f(38f), fontWeight = FontWeight.Bold, color = Ink, maxLines = 2)
                                if (w.example.isNotEmpty()) {
                                    Spacer(Modifier.height(d(4f)))
                                    Text(w.example, fontSize = f(30f), lineHeight = f(34f), color = Ink, fontWeight = FontWeight.Medium)
                                    Text(w.examplePinyin, fontSize = f(24f), lineHeight = f(28f), color = PinyinPurple)
                                    Text(w.exampleMeaning, fontSize = f(25f), lineHeight = f(30f), color = Gray)
                                }
                            }
                        }
                    }
                }

                // ---------- ปุ่มก้อนเมฆ 3 ปุ่ม ----------
                CloudButton(R.drawable.ui_btn_red, 24f, 1190f, 252f, 156f, 9f, 10f, u, 3) { vm.rate(Srs.Rating.AGAIN) }
                CloudButton(R.drawable.ui_btn_green, 300f, 1190f, 243f, 156f, 9f, 10f, u, 4) { vm.rate(Srs.Rating.GOOD) }
                CloudButton(R.drawable.ui_btn_purple, 567f, 1190f, 252f, 156f, 9f, 10f, u, 5) { vm.rate(Srs.Rating.KNOWN) }

                Box(Modifier.offset(d(560f), d(1366f)).size(d(260f), d(50f)), contentAlignment = Alignment.CenterEnd) {
                    Text(
                        "ข้าม ›", fontSize = f(28f), fontWeight = FontWeight.Bold, color = Ink,
                        modifier = Modifier.clickable { vm.skip() }.padding(horizontal = 8.dp),
                    )
                }
            }
        }
    }
}

/** กล่องที่ลอยขยับแบบสุ่มช้าๆ ภายใน ±rangeX, ±rangeY (หน่วยอ้างอิง) จึงไม่หลุดจอ */
@Composable
private fun Floaty(
    modifier: Modifier,
    rangeX: Float,
    rangeY: Float,
    u: Float,
    seed: Int,
    content: @Composable BoxScope.() -> Unit,
) {
    val ox = remember { Animatable(0f) }
    val oy = remember { Animatable(0f) }
    LaunchedEffect(seed) {
        val rnd = Random(seed * 7919 + System.nanoTime().toInt())
        while (true) {
            val tx = (rnd.nextFloat() * 2f - 1f) * rangeX
            val ty = (rnd.nextFloat() * 2f - 1f) * rangeY
            val dur = 2600 + rnd.nextInt(2600)
            coroutineScope {
                launch { ox.animateTo(tx, tween(dur, easing = FastOutSlowInEasing)) }
                launch { oy.animateTo(ty, tween(dur, easing = FastOutSlowInEasing)) }
            }
        }
    }
    Box(
        modifier.graphicsLayer {
            translationX = ox.value * u * density
            translationY = oy.value * u * density
        },
        content = content,
    )
}

@Composable
private fun CloudButton(
    res: Int, x: Float, y: Float, w: Float, h: Float,
    rangeX: Float, rangeY: Float, u: Float, seed: Int, onClick: () -> Unit,
) {
    val src = remember { MutableInteractionSource() }
    Floaty(
        Modifier
            .offset((x * u).dp, (y * u).dp)
            .size((w * u).dp, (h * u).dp)
            .clickable(interactionSource = src, indication = null) { onClick() },
        rangeX, rangeY, u, seed,
    ) {
        Image(
            painterResource(res), null,
            Modifier.size((w * u).dp, (h * u).dp), contentScale = ContentScale.FillBounds,
        )
    }
}
