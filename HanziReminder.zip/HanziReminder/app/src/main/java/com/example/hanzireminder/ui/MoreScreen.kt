@file:OptIn(ExperimentalMaterial3Api::class)

package com.example.hanzireminder.ui

import android.app.TimePickerDialog
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.hanzireminder.MainViewModel
import com.example.hanzireminder.data.SrsConfig

@Composable
fun MoreScreen(vm: MainViewModel) {
    val ctx = LocalContext.current
    val times by vm.times.collectAsStateWithLifecycle()
    val levels by vm.levels.collectAsStateWithLifecycle()
    val cfg by vm.srs.collectAsStateWithLifecycle()
    val message by vm.message.collectAsStateWithLifecycle()

    val exportLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.CreateDocument("application/json"),
    ) { uri -> if (uri != null) vm.exportTo(uri) }
    val importLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.OpenDocument(),
    ) { uri -> if (uri != null) vm.importFrom(uri) }

    LazyColumn(
        modifier = Modifier.fillMaxWidth(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        item {
            Text("เพิ่มเติม", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        }

        // ---------- เวลาแจ้งเตือน ----------
        item {
            SectionCard("⏰ เวลาแจ้งเตือนทุกวัน", MaterialTheme.colorScheme.primaryContainer) {
                times.sorted().forEach { t ->
                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                        Text(t, Modifier.weight(1f), style = MaterialTheme.typography.titleMedium)
                        TextButton(onClick = { vm.removeTime(t) }) { Text("ลบ", color = Berry) }
                    }
                }
                Button(onClick = {
                    TimePickerDialog(
                        ctx,
                        { _, h, m -> vm.addTime("%02d:%02d".format(h, m)) },
                        8, 0, true,
                    ).show()
                }) { Text("+ เพิ่มเวลา") }
            }
        }

        // ---------- ระดับ HSK ----------
        item {
            SectionCard("📚 ระดับ HSK ที่เรียน", MaterialTheme.colorScheme.secondaryContainer) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    vm.availableLevels.forEach { lv ->
                        FilterChip(
                            selected = lv in levels,
                            onClick = {
                                val next = if (lv in levels) levels - lv else levels + lv
                                vm.setLevels(next) // ต้องเลือกอย่างน้อย 1 ระดับ
                            },
                            label = { Text("HSK $lv") },
                        )
                    }
                }
                Text(
                    "ระดับ HSK อื่นๆ จะเพิ่มในอัปเดตถัดไป",
                    style = MaterialTheme.typography.bodySmall,
                    color = InkSoft,
                )
            }
        }

        // ---------- ช่วงเวลาทบทวน ----------
        item {
            SectionCard("🔁 ช่วงเวลาทบทวน", MaterialTheme.colorScheme.tertiaryContainer) {
                Text("ความถี่โดยรวม (ปุ่ม \"รู้\")", fontWeight = FontWeight.Medium)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf(0 to "ถี่", 1 to "ปกติ", 2 to "ห่างๆ").forEach { (v, label) ->
                        FilterChip(
                            selected = cfg.speed == v,
                            onClick = { vm.setSrs(cfg.copy(speed = v)) },
                            label = { Text(label) },
                        )
                    }
                }
                Text(
                    when (cfg.speed) {
                        0 -> "4 ชม. → 12 ชม. → 1.5 วัน → 3.5 วัน → 7 วัน → 15 วัน"
                        2 -> "16 ชม. → 2 วัน → 6 วัน → 14 วัน → 28 วัน → 60 วัน"
                        else -> "8 ชม. → 1 วัน → 3 วัน → 7 วัน → 14 วัน → 30 วัน"
                    },
                    style = MaterialTheme.typography.bodySmall,
                    color = InkSoft,
                )

                Text("กด \"ไม่รู้\" แล้วเจออีกใน", fontWeight = FontWeight.Medium)
                Row(
                    modifier = Modifier.horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    listOf(5, 10, 30, 60).forEach { m ->
                        FilterChip(
                            selected = cfg.againMinutes == m,
                            onClick = { vm.setSrs(cfg.copy(againMinutes = m)) },
                            label = { Text("$m นาที") },
                        )
                    }
                }

                Text("กด \"รู้แล้ว\" แล้วเจออีกใน", fontWeight = FontWeight.Medium)
                Row(
                    modifier = Modifier.horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    listOf(30, 60, 90, 180).forEach { d ->
                        FilterChip(
                            selected = cfg.knownDays == d,
                            onClick = { vm.setSrs(cfg.copy(knownDays = d)) },
                            label = { Text("$d วัน") },
                        )
                    }
                }
                TextButton(onClick = { vm.setSrs(SrsConfig()) }) { Text("คืนค่าเริ่มต้น") }
            }
        }

        // ---------- สำรอง / กู้คืน ----------
        item {
            SectionCard("💾 สำรอง / กู้คืนความคืบหน้า", MaterialTheme.colorScheme.surfaceVariant) {
                Text(
                    "เก็บไฟล์ไว้ก่อนอัปเดตหรือเปลี่ยนเครื่อง จะได้ไม่เสียสิ่งที่เรียนมา",
                    style = MaterialTheme.typography.bodySmall,
                    color = InkSoft,
                )
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    Button(onClick = { exportLauncher.launch("hanzi-backup.json") }) { Text("สำรองข้อมูล") }
                    OutlinedButton(onClick = {
                        importLauncher.launch(arrayOf("application/json", "text/plain", "*/*"))
                    }) { Text("กู้คืน") }
                }
                val msg = message
                if (msg != null) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(msg, Modifier.weight(1f), color = Coral, fontWeight = FontWeight.Medium)
                        TextButton(onClick = { vm.clearMessage() }) { Text("ปิด") }
                    }
                }
            }
        }

        item {
            Text(
                "学中文 Reminder · เวอร์ชัน 2.0",
                style = MaterialTheme.typography.bodySmall,
                color = InkSoft,
            )
        }
    }
}

@Composable
private fun SectionCard(
    title: String,
    color: androidx.compose.ui.graphics.Color,
    content: @Composable () -> Unit,
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = color),
    ) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            content()
        }
    }
}
