package com.example.hanzireminder.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.Text
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

// พาเลตต์สีสดใส น่ารัก
val Coral = Color(0xFFFF6B8B)
val Sunny = Color(0xFFFFB84D)
val Sky = Color(0xFF5AB8F5)
val Mint = Color(0xFF3FCB9B)
val Berry = Color(0xFFEF5350)
val Grape = Color(0xFF8E7CFF)
val InkDark = Color(0xFF2B2230)
val InkSoft = Color(0xFF7A6F80)
val Cream = Color(0xFFFFF7F2)

private val CuteColors = lightColorScheme(
    primary = Coral,
    onPrimary = Color.White,
    primaryContainer = Color(0xFFFFE0E8),
    onPrimaryContainer = Color(0xFF5A1426),
    secondary = Sky,
    onSecondary = Color.White,
    secondaryContainer = Color(0xFFDDF1FF),
    onSecondaryContainer = Color(0xFF0B3A5B),
    tertiary = Sunny,
    onTertiary = Color(0xFF3A2600),
    tertiaryContainer = Color(0xFFFFF0CC),
    onTertiaryContainer = Color(0xFF5A3D00),
    background = Cream,
    onBackground = InkDark,
    surface = Color.White,
    onSurface = InkDark,
    surfaceVariant = Color(0xFFFDEEF2),
    onSurfaceVariant = InkSoft,
    outline = Color(0xFFE5C9D1),
)

private val CuteShapes = Shapes(
    small = RoundedCornerShape(14.dp),
    medium = RoundedCornerShape(22.dp),
    large = RoundedCornerShape(30.dp),
)

@Composable
fun HanziTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = CuteColors, shapes = CuteShapes, content = content)
}

/** หลอดความคืบหน้า (0f..1f) สีไล่เฉด */
@Composable
fun ProgressBar(progress: Float, modifier: Modifier = Modifier) {
    val p = progress.coerceIn(0f, 1f)
    Box(
        modifier = modifier
            .fillMaxWidth()
            .height(20.dp)
            .clip(RoundedCornerShape(10.dp))
            .background(Color.White),
    ) {
        if (p > 0f) {
            Box(
                modifier = Modifier
                    .fillMaxWidth(p.coerceAtLeast(0.04f))
                    .fillMaxHeight()
                    .clip(RoundedCornerShape(10.dp))
                    .background(Brush.horizontalGradient(listOf(Coral, Sunny))),
            )
        }
    }
}

@Composable
fun BigButton(label: String, color: Color, modifier: Modifier = Modifier, onClick: () -> Unit) {
    Button(
        onClick = onClick,
        modifier = modifier,
        colors = ButtonDefaults.buttonColors(containerColor = color, contentColor = Color.White),
    ) {
        Text(label, fontSize = 15.sp, modifier = Modifier.padding(vertical = 4.dp))
    }
}
