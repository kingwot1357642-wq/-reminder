package com.example.hanzireminder.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.ui.Alignment
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.Text
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

// ธีมแมวม่วง
val Violet = Color(0xFF7B4FD6) // ม่วงหลัก
val Lilac = Color(0xFF9560E8) // ม่วงอ่อน (พินอิน)
val Gold = Color(0xFFFFC145) // ตาแมว
val Rose = Color(0xFFFF8FB8) // จมูกแมว
val Mint = Color(0xFF3FCB9B)
val Berry = Color(0xFFEF5350)
val InkDark = Color(0xFF2A2140)
val InkSoft = Color(0xFF776C8C)
val Cream = Color(0xFFF7F1FF)

private val CatColors = lightColorScheme(
    primary = Violet,
    onPrimary = Color.White,
    primaryContainer = Color(0xFFE9DDFF),
    onPrimaryContainer = Color(0xFF2D1670),
    secondary = Lilac,
    onSecondary = Color.White,
    secondaryContainer = Color(0xFFDCCBFF),
    onSecondaryContainer = Color(0xFF2D1670),
    tertiary = Gold,
    onTertiary = Color(0xFF3A2600),
    tertiaryContainer = Color(0xFFFFEBBD),
    onTertiaryContainer = Color(0xFF5A3D00),
    background = Cream,
    onBackground = InkDark,
    surface = Color.White,
    onSurface = InkDark,
    surfaceVariant = Color(0xFFF0E8FF),
    onSurfaceVariant = InkSoft,
    outline = Color(0xFFD2C4EE),
    surfaceContainer = Color(0xFFF0E8FF),
)

private val CatShapes = Shapes(
    small = RoundedCornerShape(14.dp),
    medium = RoundedCornerShape(22.dp),
    large = RoundedCornerShape(30.dp),
)

@Composable
fun HanziTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = CatColors, shapes = CatShapes, content = content)
}

/** หลอดความคืบหน้า (0f..1f) ไล่เฉดม่วง พร้อมรอยเท้าแมวที่ปลายหลอด */
@Composable
fun ProgressBar(progress: Float, modifier: Modifier = Modifier) {
    val p = progress.coerceIn(0.04f, 0.96f)
    Box(modifier = modifier.fillMaxWidth().height(32.dp)) {
        Box(
            modifier = Modifier
                .align(Alignment.CenterStart)
                .fillMaxWidth()
                .height(18.dp)
                .clip(RoundedCornerShape(9.dp))
                .background(Color(0xFFE9DDFF)),
        ) {
            Box(
                modifier = Modifier
                    .fillMaxWidth(p)
                    .fillMaxHeight()
                    .clip(RoundedCornerShape(9.dp))
                    .background(Brush.horizontalGradient(listOf(Violet, Color(0xFFB58BF2)))),
            )
        }
        Row(Modifier.fillMaxWidth().align(Alignment.CenterStart)) {
            Spacer(Modifier.weight(p))
            Box(
                modifier = Modifier
                    .offset(x = (-16).dp)
                    .size(32.dp)
                    .clip(CircleShape)
                    .background(Color.White),
                contentAlignment = Alignment.Center,
            ) { Text("🐾", fontSize = 16.sp) }
            Spacer(Modifier.weight(1f - p))
        }
    }
}

@Composable
fun BigButton(label: String, color: Color, modifier: Modifier = Modifier, onClick: () -> Unit) {
    Button(
        onClick = onClick,
        modifier = modifier.height(52.dp),
        shape = RoundedCornerShape(50),
        colors = ButtonDefaults.buttonColors(containerColor = color, contentColor = Color.White),
    ) {
        Text(label, fontSize = 15.sp, modifier = Modifier.padding(vertical = 4.dp))
    }
}
