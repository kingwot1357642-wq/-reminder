@file:OptIn(ExperimentalMaterial3Api::class)

package com.example.hanzireminder.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.hanzireminder.MainViewModel
import com.example.hanzireminder.data.Status
import com.example.hanzireminder.data.Word
import com.example.hanzireminder.data.status

fun statusLabel(s: Status) = when (s) {
    Status.NEW -> "ใหม่"
    Status.LEARNING -> "กำลังเรียน"
    Status.KNOWN -> "รู้แล้ว"
}

fun statusColor(s: Status): Color = when (s) {
    Status.NEW -> InkSoft
    Status.LEARNING -> Sunny
    Status.KNOWN -> Mint
}

@Composable
fun WordsScreen(vm: MainViewModel) {
    val words by vm.visibleWords.collectAsStateWithLifecycle()

    var query by remember { mutableStateOf("") }
    var filter by remember { mutableStateOf(0) } // 0 ทั้งหมด 1 ใหม่ 2 กำลังเรียน 3 รู้แล้ว
    var expandedId by remember { mutableStateOf(-1L) }
    var showAdd by remember { mutableStateOf(false) }
    var hanzi by remember { mutableStateOf("") }
    var pinyin by remember { mutableStateOf("") }
    var meaning by remember { mutableStateOf("") }

    val shown = remember(words, filter, query) {
        val q = query.trim().lowercase()
        words.filter {
            val okStatus = when (filter) {
                1 -> it.status() == Status.NEW
                2 -> it.status() == Status.LEARNING
                3 -> it.status() == Status.KNOWN
                else -> true
            }
            val okQuery = q.isEmpty() ||
                it.hanzi.contains(q) ||
                it.pinyin.lowercase().contains(q) ||
                it.meaning.lowercase().contains(q)
            okStatus && okQuery
        }
    }

    LazyColumn(
        modifier = Modifier.fillMaxWidth(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        item {
            Text(
                "คำศัพท์ (${shown.size})",
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold,
            )
        }
        item {
            OutlinedTextField(
                value = query,
                onValueChange = { query = it },
                label = { Text("ค้นหา (จีน / พินอิน / ไทย)") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth(),
            )
        }
        item {
            Row(
                modifier = Modifier.horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(6.dp),
            ) {
                FilterChip(selected = filter == 0, onClick = { filter = 0 }, label = { Text("ทั้งหมด") })
                FilterChip(selected = filter == 1, onClick = { filter = 1 }, label = { Text("ใหม่") })
                FilterChip(selected = filter == 2, onClick = { filter = 2 }, label = { Text("กำลังเรียน") })
                FilterChip(selected = filter == 3, onClick = { filter = 3 }, label = { Text("รู้แล้ว") })
            }
        }
        item {
            TextButton(onClick = { showAdd = !showAdd }) {
                Text(if (showAdd) "ปิดฟอร์มเพิ่มคำ" else "+ เพิ่มคำศัพท์เอง")
            }
        }
        if (showAdd) {
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.tertiaryContainer),
                ) {
                    Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        OutlinedTextField(hanzi, { hanzi = it }, label = { Text("ตัวอักษรจีน") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                        OutlinedTextField(pinyin, { pinyin = it }, label = { Text("พินอิน") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                        OutlinedTextField(meaning, { meaning = it }, label = { Text("ความหมาย") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                        Button(onClick = {
                            vm.addWord(hanzi, pinyin, meaning)
                            hanzi = ""; pinyin = ""; meaning = ""
                            showAdd = false
                        }) { Text("บันทึกคำ") }
                    }
                }
            }
        }
        items(shown, key = { it.id }) { w ->
            WordRow(
                word = w,
                expanded = expandedId == w.id,
                onToggle = { expandedId = if (expandedId == w.id) -1L else w.id },
                onDelete = { vm.deleteWord(w) },
            )
        }
    }
}

@Composable
private fun WordRow(
    word: Word,
    expanded: Boolean,
    onToggle: () -> Unit,
    onDelete: () -> Unit,
) {
    Card(
        modifier = Modifier.fillMaxWidth().clickable { onToggle() },
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
    ) {
        Column(Modifier.padding(horizontal = 14.dp, vertical = 10.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(word.hanzi, fontSize = 24.sp, fontWeight = FontWeight.Bold)
                Column(Modifier.weight(1f).padding(horizontal = 12.dp)) {
                    Text(word.pinyin, color = Sky, fontSize = 14.sp)
                    Text(word.meaning, fontSize = 14.sp)
                }
                Column(horizontalAlignment = Alignment.End) {
                    val s = word.status()
                    Text(statusLabel(s), color = statusColor(s), fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    if (word.level > 0) Text("HSK ${word.level}", color = InkSoft, fontSize = 11.sp)
                }
            }
            if (expanded) {
                if (word.example.isNotEmpty()) {
                    Column(Modifier.padding(top = 8.dp), verticalArrangement = Arrangement.spacedBy(1.dp)) {
                        Text(word.example, fontSize = 15.sp)
                        Text(word.examplePinyin, fontSize = 12.sp, color = InkSoft)
                        Text(word.exampleMeaning, fontSize = 13.sp, color = InkSoft)
                    }
                }
                if (!word.isBuiltIn) {
                    TextButton(onClick = onDelete) { Text("ลบคำนี้", color = Berry) }
                }
            }
        }
    }
}
