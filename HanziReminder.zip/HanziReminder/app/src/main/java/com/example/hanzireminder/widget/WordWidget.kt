package com.example.hanzireminder.widget

import android.content.Context
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.longPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.glance.GlanceId
import androidx.glance.GlanceModifier
import androidx.glance.action.ActionParameters
import androidx.glance.action.actionParametersOf
import androidx.glance.action.clickable
import androidx.glance.appwidget.GlanceAppWidget
import androidx.glance.appwidget.GlanceAppWidgetReceiver
import androidx.glance.appwidget.action.ActionCallback
import androidx.glance.appwidget.action.actionRunCallback
import androidx.glance.appwidget.action.actionStartActivity
import androidx.glance.appwidget.provideContent
import androidx.glance.appwidget.state.getAppWidgetState
import androidx.glance.appwidget.state.updateAppWidgetState
import androidx.glance.background
import androidx.glance.currentState
import androidx.glance.layout.Alignment
import androidx.glance.layout.Column
import androidx.glance.layout.Row
import androidx.glance.layout.Spacer
import androidx.glance.layout.fillMaxSize
import androidx.glance.layout.fillMaxWidth
import androidx.glance.layout.padding
import androidx.glance.layout.width
import androidx.glance.state.GlanceStateDefinition
import androidx.glance.state.PreferencesGlanceStateDefinition
import androidx.glance.text.FontWeight
import androidx.glance.text.Text
import androidx.glance.text.TextAlign
import androidx.glance.text.TextStyle
import androidx.glance.unit.ColorProvider
import com.example.hanzireminder.MainActivity
import com.example.hanzireminder.data.Repository
import com.example.hanzireminder.data.Srs

private val WID = longPreferencesKey("wid")
private val HANZI = stringPreferencesKey("hanzi")
private val PINYIN = stringPreferencesKey("pinyin")
private val MEANING = stringPreferencesKey("meaning")
private val EXAMPLE = stringPreferencesKey("example")
private val EXAMPLE_PINYIN = stringPreferencesKey("example_pinyin")
private val EXAMPLE_MEANING = stringPreferencesKey("example_meaning")

private val RATING_KEY = ActionParameters.Key<String>("rating")

/**
 * เลย์เอาต์: ตัวจีน (บนซ้าย) + พินอิน (ต่อทางขวา)
 * ความหมาย และประโยคตัวอย่างอยู่ถัดลงมา ปุ่ม ไม่รู้ / รู้ อยู่ล่างสุด
 */
class WordWidget : GlanceAppWidget() {

    override val stateDefinition: GlanceStateDefinition<*> = PreferencesGlanceStateDefinition

    override suspend fun provideGlance(context: Context, id: GlanceId) {
        val prefs = getAppWidgetState(context, PreferencesGlanceStateDefinition, id)
        if (prefs[WID] == null) pickNext(context, id)
        provideContent { Content() }
    }

    @Composable
    private fun Content() {
        val prefs = currentState<Preferences>()
        val dark = ColorProvider(Color(0xFF2B2230))
        val soft = ColorProvider(Color(0xFF7A6F80))
        val coral = ColorProvider(Color(0xFFFF6B8B))
        val sky = ColorProvider(Color(0xFF2E9BE0))

        Column(
            modifier = GlanceModifier
                .fillMaxSize()
                .background(ColorProvider(Color(0xFFFFF1EC)))
                .padding(12.dp)
                .clickable(actionStartActivity<MainActivity>()),
            verticalAlignment = Alignment.Top,
        ) {
            Row(
                modifier = GlanceModifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Text(
                    text = prefs[HANZI] ?: "…",
                    style = TextStyle(fontSize = 32.sp, fontWeight = FontWeight.Bold, color = coral),
                )
                Spacer(modifier = GlanceModifier.width(10.dp))
                Text(
                    text = prefs[PINYIN].orEmpty(),
                    style = TextStyle(fontSize = 17.sp, color = sky),
                )
            }
            Text(
                text = prefs[MEANING].orEmpty(),
                modifier = GlanceModifier.padding(top = 2.dp),
                style = TextStyle(fontSize = 15.sp, fontWeight = FontWeight.Medium, color = dark),
                maxLines = 2,
            )
            if (!prefs[EXAMPLE].isNullOrEmpty()) {
                Column(modifier = GlanceModifier.padding(top = 6.dp)) {
                    Text(
                        text = prefs[EXAMPLE].orEmpty(),
                        style = TextStyle(fontSize = 14.sp, color = dark),
                        maxLines = 2,
                    )
                    Text(
                        text = prefs[EXAMPLE_PINYIN].orEmpty(),
                        style = TextStyle(fontSize = 11.sp, color = soft),
                        maxLines = 2,
                    )
                    Text(
                        text = prefs[EXAMPLE_MEANING].orEmpty(),
                        style = TextStyle(fontSize = 12.sp, color = soft),
                        maxLines = 2,
                    )
                }
            }
            Spacer(modifier = GlanceModifier.defaultWeight())
            Row(modifier = GlanceModifier.fillMaxWidth()) {
                RateButton("ไม่รู้", Color(0xFFEF5350), "again", GlanceModifier.defaultWeight())
                Spacer(modifier = GlanceModifier.width(10.dp))
                RateButton("รู้", Color(0xFF3FCB9B), "good", GlanceModifier.defaultWeight())
            }
        }
    }

    @Composable
    private fun RateButton(label: String, color: Color, rating: String, modifier: GlanceModifier) {
        Text(
            text = label,
            modifier = modifier
                .background(ColorProvider(color))
                .padding(vertical = 10.dp)
                .clickable(actionRunCallback<RateAction>(actionParametersOf(RATING_KEY to rating))),
            style = TextStyle(
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold,
                color = ColorProvider(Color.White),
                textAlign = TextAlign.Center,
            ),
        )
    }

    companion object {
        suspend fun pickNext(context: Context, id: GlanceId) {
            val current = getAppWidgetState(context, PreferencesGlanceStateDefinition, id)[WID] ?: -1L
            val word = Repository.next(context, excludeId = current) ?: return
            updateAppWidgetState(context, id) { prefs ->
                prefs[WID] = word.id
                prefs[HANZI] = word.hanzi
                prefs[PINYIN] = word.pinyin
                prefs[MEANING] = word.meaning
                prefs[EXAMPLE] = word.example
                prefs[EXAMPLE_PINYIN] = word.examplePinyin
                prefs[EXAMPLE_MEANING] = word.exampleMeaning
            }
        }

        suspend fun rate(context: Context, id: GlanceId, rating: Srs.Rating) {
            val wordId = getAppWidgetState(context, PreferencesGlanceStateDefinition, id)[WID]
            if (wordId != null) Repository.rate(context, wordId, rating)
        }
    }
}

class RateAction : ActionCallback {
    override suspend fun onAction(context: Context, glanceId: GlanceId, parameters: ActionParameters) {
        val rating = when (parameters[RATING_KEY]) {
            "again" -> Srs.Rating.AGAIN
            else -> Srs.Rating.GOOD
        }
        WordWidget.rate(context, glanceId, rating)
        WordWidget.pickNext(context, glanceId)
        WordWidget().update(context, glanceId)
    }
}

class WordWidgetReceiver : GlanceAppWidgetReceiver() {
    override val glanceAppWidget: GlanceAppWidget = WordWidget()
}
